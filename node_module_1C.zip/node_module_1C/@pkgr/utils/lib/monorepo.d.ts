export declare const isMonorepo: boolean;
export declare const monorepoPkgs: string[];
