export declare function openBrowser(url: string): Promise<boolean>;
