# Installation
> `npm install --save @types/bcrypt`

# Summary
This package contains type definitions for bcrypt (https://www.npmjs.org/package/bcrypt).

# Details
Files were exported from https://github.com/DefinitelyTyped/DefinitelyTyped/tree/master/types/bcrypt.

### Additional Details
 * Last updated: Sun, 09 May 2021 03:31:24 GMT
 * Dependencies: [@types/node](https://npmjs.com/package/@types/node)
 * Global values: none

# Credits
These definitions were written by [ Peter Harris](https://github.com/codeanimal), [Ayman Nedjmeddine](https://github.com/IOAyman), [David Stapleton](https://github.com/dstapleton92), and [BendingBender](https://github.com/BendingBender).
