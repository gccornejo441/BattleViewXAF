export { _ as default } from "../esm/_get.js";
