export { _ as default } from "../esm/_apply_decs_2203_r.js";
