export { _ as default } from "../esm/_class_apply_descriptor_set.js";
