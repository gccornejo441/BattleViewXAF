export { _ as default } from "../esm/_interop_require_wildcard.js";
