export { _ as default } from "../esm/_update.js";
