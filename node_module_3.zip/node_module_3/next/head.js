module.exports = require('./dist/shared/lib/head')
