module.exports = require('./dist/pages/_document')
