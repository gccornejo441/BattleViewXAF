export * from 'next/dist/compiled/@next/font/dist/google'
