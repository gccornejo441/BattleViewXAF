module.exports = require('./dist/client/web-vitals')
