import getConfig from './dist/shared/lib/runtime-config'
export * from './dist/shared/lib/runtime-config'
export default getConfig
