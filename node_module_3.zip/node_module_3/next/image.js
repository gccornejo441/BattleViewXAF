module.exports = require('./dist/client/image')
