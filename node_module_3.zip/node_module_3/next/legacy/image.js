module.exports = require('../dist/client/legacy/image')
