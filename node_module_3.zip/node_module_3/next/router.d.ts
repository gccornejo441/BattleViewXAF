import Router from './dist/client/router'
export * from './dist/client/router'
export default Router
