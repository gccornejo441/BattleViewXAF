export default function css(): string;
//# sourceMappingURL=index.d.ts.map