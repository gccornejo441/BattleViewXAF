export {};
//# sourceMappingURL=client-provider.test.d.ts.map