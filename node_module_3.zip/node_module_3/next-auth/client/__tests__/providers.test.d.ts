export {};
//# sourceMappingURL=providers.test.d.ts.map