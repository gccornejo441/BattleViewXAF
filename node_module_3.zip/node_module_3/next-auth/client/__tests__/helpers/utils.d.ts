export function getBroadcastEvents(): any;
export function printFetchCalls(mockCalls: any): any;
//# sourceMappingURL=utils.d.ts.map