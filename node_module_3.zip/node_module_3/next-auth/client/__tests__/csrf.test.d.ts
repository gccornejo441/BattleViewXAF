export {};
//# sourceMappingURL=csrf.test.d.ts.map