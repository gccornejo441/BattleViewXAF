import { CallbacksOptions } from "../..";
export declare const defaultCallbacks: CallbacksOptions;
//# sourceMappingURL=default-callbacks.d.ts.map