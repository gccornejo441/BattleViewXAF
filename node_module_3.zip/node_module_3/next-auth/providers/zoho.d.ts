export default function Zoho(options: Partial<import("./oauth").OAuthConfig<any>>): import("./oauth").OAuthConfig<any>;
//# sourceMappingURL=zoho.d.ts.map