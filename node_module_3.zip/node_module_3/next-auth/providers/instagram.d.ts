export default function Instagram(options: Partial<import("src/providers").OAuthConfig<any>>): import("src/providers").OAuthConfig<any>;
//# sourceMappingURL=instagram.d.ts.map