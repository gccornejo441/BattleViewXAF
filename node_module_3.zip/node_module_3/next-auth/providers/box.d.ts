export default function Box(options: Partial<import("./oauth").OAuthConfig<any>>): import("./oauth").OAuthConfig<any>;
//# sourceMappingURL=box.d.ts.map