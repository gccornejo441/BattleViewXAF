require('preact/compat');

module.exports = require('preact/jsx-runtime');
