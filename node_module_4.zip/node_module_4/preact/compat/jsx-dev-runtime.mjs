import 'preact/compat';

export * from 'preact/jsx-runtime';
