/**
 * Reset the history of which prop type warnings have been logged.
 */
export function resetPropWarnings(): void;
