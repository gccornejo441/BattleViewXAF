let preinstall
try {
  preinstall = require('../preinstall/index.js')
} catch (e) {
  //
}
if (preinstall) {
  preinstall.main()
}
