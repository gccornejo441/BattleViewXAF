module.exports = require('./dist/jsx'); // eslint-disable-line
